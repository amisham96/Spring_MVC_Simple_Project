package com.mindtree.librarybook.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.librarybook.entity.Book;
import com.mindtree.librarybook.entity.Library;
import com.mindtree.librarybook.exception.ApplicationException;
import com.mindtree.librarybook.exception.ServiceException;
import com.mindtree.librarybook.service.BookService;
import com.mindtree.librarybook.service.LibraryService;
import com.mindtree.librarybook.service.impl.Libraryservice;

@Controller
public class LibraryBookController {

	@Autowired
	LibraryService libraryService;
	@Autowired
	BookService bookService;
	@Autowired
	static Library library;

	@RequestMapping("/")
	public ModelAndView getLibrary(ModelAndView mav) {

		List<Library> listLibrary = libraryService.getlibraries();
		mav.addObject("listLibrary", listLibrary);
		mav.setViewName("librarymanagement");
		return mav;

	}

	@RequestMapping("/addlibrary")
	public String bookingLibrary(Model model) {

		Library library = new Library();

		model.addAttribute("library", library);
		return "addLibrary";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveLibrary(@ModelAttribute("person") Library library) {

		libraryService.addlibrary(library);

		return "redirect:/";
	}

	@RequestMapping("/edit/{id}")
	public ModelAndView EditLibrary(@PathVariable(name = "id") int libraryId) {
		ModelAndView mav = new ModelAndView("edit_person");
		Library library = libraryService.getLibraryById(libraryId);
		mav.addObject("library", library);
		return mav;
	}

	@RequestMapping(value = "saveupdate", method = RequestMethod.POST)
	public String save(@ModelAttribute("library") Library Library) {
		libraryService.addlibrary(Library);
		return "librarymanagement";
	}

	@RequestMapping("/showdetails")
	public ModelAndView viewDropDown(ModelAndView mav) {
		List<Library> libraries = libraryService.getlibraries();
		mav.setViewName("delete_library");
		mav.addObject("libraries", libraries);
		return mav;
	}

	@RequestMapping("/deletelib")
	public String deleteLibrary(@RequestParam("libraryId") int libraryId) {

		libraryService.deleteLibrary(libraryId);
		return "redirect:/";
	}

	@RequestMapping("/details/{id}")
	public ModelAndView getBooks(@PathVariable(name = "id") int libraryId, ModelAndView mav) {
		Library library1 = libraryService.getLibraryById(libraryId);
		List<Book> listbook = library1.getBooks();
		library = library1;
		mav.addObject("libraryId", libraryId);
		mav.addObject("listbook", listbook);
		mav.setViewName("bookmanagement");
		return mav;

	}

	@RequestMapping(value = "/details/addbook", method = RequestMethod.GET)
	public String bookingbook(Model model) {

		Book book = new Book();

		model.addAttribute("book", book);
		return "addBook";
	}

	@RequestMapping(value = "savebook", method = RequestMethod.POST)
	public String saveBook(@ModelAttribute("book") Book book) {
		book.setLibrary(library);
		bookService.addlibrary(book);

		return "redirect:/";
	}

	@RequestMapping("/details/editbook/{id}")
	public ModelAndView editBook(@PathVariable(name="id") int bookId) {
		System.out.println(bookId);
		ModelAndView mav = new ModelAndView("edit_book");

		Book book = bookService.getLibraryById(bookId);
		System.out.println(book.toString());
		mav.addObject("book", book);
		return mav;
	}

	@RequestMapping(value = "saves", method = RequestMethod.POST)
	public String savebook(@ModelAttribute("book") Book book) {
		bookService.updateBook(book,library);
		book.setLibrary(library);
		bookService.addlibrary(book);
		return "redirect:/";
	}

	@RequestMapping("/details/showdetail")
	public ModelAndView viewDropDowns(ModelAndView mav) {
		int libraryId = library.getLibraryId();
		List<Book> books = bookService.listAllBook(libraryId);
		mav.setViewName("delete_book");
		mav.addObject("books", books);
		return mav;
	}

	@RequestMapping("/details/showdetail/deletebook")
	public String deleteBooks(@RequestParam("bookId") int bookId) {
		System.out.println(bookId);
		bookService.deleteLibrary(bookId);
		return "redirect:/";
	}
}
