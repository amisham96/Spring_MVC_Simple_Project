package com.mindtree.librarybook.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.librarybook.entity.Book;

@Repository
public interface BookRepo extends JpaRepository<Book, Integer> {

}
