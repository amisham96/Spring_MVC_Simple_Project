package com.mindtree.librarybook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarybookApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarybookApplication.class, args);
	}

}
