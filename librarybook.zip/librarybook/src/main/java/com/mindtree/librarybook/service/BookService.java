package com.mindtree.librarybook.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.librarybook.entity.Book;
import com.mindtree.librarybook.entity.Library;
import com.mindtree.librarybook.exception.ServiceException;

@Service
public interface BookService {
	Book addlibrary(Book book);

	Book getLibraryById(int bookId);

	void deleteLibrary(int bookId);

	List<Book> listAllBook(int libraryId);

	void updateBook(Book book,Library library);
}
