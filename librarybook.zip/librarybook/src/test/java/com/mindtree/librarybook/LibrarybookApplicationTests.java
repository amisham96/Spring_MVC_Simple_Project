package com.mindtree.librarybook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarybookApplicationTests {

	@Test
	void contextLoads() {
	}

}
